# Explicit finite extraction from convolution profiles for matrix multiplication

This revised manuscript gives a self-contained finite construction from convolution tensor relations. For every positive rational allowance above exponent 9/4, it specifies integer parameters, an exact relative multiplication scheme, a coefficient field, and a terminating construction of a rational bilinear seed. It does not claim a fixed seed of exponent exactly 9/4 or practical performance.

The revision integrates multiway determinant restrictions, threefold orientation balancing, tripling with only the middle count fixed, rational occupation flows, circulation rounding, and pooled recursion. A new explicit rate theorem gives exponent less than `9/4 + 900/log(a)` for `a >= 2^64`, with `log(A) <= 181 a^5 ceil(log2(a))^2`. This bounds the relative scheme's source side `A`, not the final rational seed dimension or coefficient-generation complexity. The exact binary certificate and its denominator bound are retained as an appendix benchmark.

## Files and build

`main.tex` is the entry point. Keep the section files and `references.bib` in the same directory. No author names are included.

- `finite-extraction.pdf`: revised paper.
- `finite-extraction-source.zip`: current source package.
- `finite-extraction-supplement-v2.zip`: versioned supporting scripts, saved reports, component tests, derivations, and integrity hashes.
- `archive/v1/`: previous PDF and source package.
- `finite-extraction-supplement-v1.zip`: preserved previous supplement.

Build with TeX Live containing pdfLaTeX, BibTeX, latexmk, Latin Modern, microtype, natbib, and xurl:

```sh
make -C manuscript
```

The PDF is written to `manuscript/finite-extraction.pdf`; intermediate files stay in `manuscript/build/`. From inside this directory, use `make`.

## Evidence and scope

The main theorems are symbolic proofs. The finite example uses saved exact-arithmetic intervals. No research experiments were rerun during revision. Source-hash checks, compilation, document inspection, and archive validation are separate from mathematical verification.

The principal supporting files are:

- `experiments/multiway_determinant.py` and `results/multiway-determinant.json` for the determinant bases and exact type maps.
- `experiments/cyclic_profile_extraction.py` and `results/cyclic-profile-extraction.json` for orientation bookkeeping and partial-middle tripling.
- `experiments/multiway_profile_flows.py` and `results/multiway-profile-flows.json` for rational occupation flows.
- `experiments/multiway_rounded_flow.py` and `results/multiway-rounded-flow.json` for conserved integer counts.
- `experiments/multiway_finite_costs.py` and `results/multiway-finite-costs.json` for the finite examples and their rational interval certificates.
- `experiments/general_profile_extraction.py` and `results/general-profile-extraction.json` for the exact binary certificate.

The paper specifies complete maps as mathematical algorithms. There is no implementation that expands the full coefficient arrays at the claimed exponent allowances. The supplement's research notes preserve earlier project stages; the manuscript supersedes their presentation of the completed construction.

Independent mathematical and editorial reports, the Opus reviews, the literature audit, and responses are recorded under `docs/manuscript-v2-*.md`. Review records supplement the proofs and do not substitute for journal peer review.
